import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class AlphaPart extends Partitioner<Text,IntWritable> {

	@Override
	public int getPartition(Text key, IntWritable value, int noofredu) {
		System.out.println("==================IN PARTITIONER");
		char ch=key.toString().toLowerCase().charAt(0);
		if(ch >=97 && ch<=109){
			return 0;
		}else if(ch>109 && ch<123){
			return 1;
		}else return 2;
	}

	
	
}

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class WordCountMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

	@Override
	protected void setup(Mapper<LongWritable, Text, Text, IntWritable>.Context context)
			throws IOException, InterruptedException {
	System.out.println("++++++Inside MAPPER SETUP");
	}
	
	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, IntWritable>.Context context)
			throws IOException, InterruptedException {
	System.out.println("------Inside MAPPER map");
	
		StringTokenizer tokens=new StringTokenizer(value.toString(), " ");
	while(tokens.hasMoreTokens()){
			context.write(new Text(tokens.nextToken()), new IntWritable(1));
		}
	
	
	}
	
	@Override
	protected void cleanup(Mapper<LongWritable, Text, Text, IntWritable>.Context context)
			throws IOException, InterruptedException {
		System.out.println("******Inside MAPPER CLEANUP");

	}
	
	
}

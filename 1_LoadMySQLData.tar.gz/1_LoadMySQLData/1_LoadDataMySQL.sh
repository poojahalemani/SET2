
#!/bin/bash
##############################################################################
# Name		: LoadDataMySQL.sh
# Description	: This program creates a database for consumer complaints and loads data in to complaints table.
# PreCondition	: Run commands from current folder, the data folder should be present
# Inputs	: mysql username,password 
#
# Version Date       Programmer    Description
# ======= ========== ===========   ======================================
# 1.0     08/08/2016 Dorababu G     Initial version
# 	      
##############################################################################


#Create database 'Consumer'

echo -n "Enter Your Mysql User Name::"
read  username

echo -n "Enter Your Mysql Password::"
stty -echo; read passwd; stty echo;

echo "password is :: $passwd"

#NOTE - give space after fn_name and parenthesis
print_comments ( ){
	echo "**************************************"
	echo $message
	echo "**************************************"
	}

export message="Creating Mysql Database 'complaints'";
# Print message
print_comments

#SET PASSWORD FOR 'root'@'localhost' = PASSWORD('root');
#SET PASSWORD FOR 'root'@'%' = PASSWORD('root');

mysql --user=$username --password=$passwd -e "create database if not exists complaints_db" 

if [ $? -eq 0 ] ;
then
	#Donot give space after =, otherwise gives error
	export message=" Database complaints created successfully"
	print_comments
else
	export message=" failure in creating database"
	print_comments
	exit 0
fi


export message="Creating complants table in database"
print_comments

mysql --user=$username --password=$passwd -e "

create table if not exists complaints_db.complaints (Date_received varchar(20),
Product varchar(256),
Sub_product varchar(256),
Issue varchar(256),
Sub_issue varchar(256),
Consumer_complaint_narrative Text,
Company_public_response varchar(256),
Company varchar(256),
State varchar(256),
ZIP_code varchar(256),
Tags varchar(256),
Consumer_consent_provided varchar(256),
Submitted_via varchar(256),
Date_sent_to_company varchar(256),
Company_response_to_consumer varchar(256),
Timely_response varchar(256),
Consumer_disputed varchar(256),
Complaint_ID bigint ,
-- created_date datetime DEFAULT CURRENT_TIMESTAMP,
-- modified_date datetime DEFAULT CURRENT_TIMESTAMP,

created_date timestamp DEFAULT CURRENT_TIMESTAMP,
modified_date timestamp DEFAULT CURRENT_TIMESTAMP,

id BIGINT NOT NULL AUTO_INCREMENT,
PRIMARY KEY(id)) " ;

if [ $? -eq 0 ] ;
then
	#Donot give space after =, otherwise gives error
	export message="Table created successfully"
	print_comments
else
	export message="Failure in creating table"
	print_comments
	exit 0
fi

export message="loading data into table complaints"
print_comments

echo -n "Reload data into complaints table???(Y/N)::"
read option
echo "Your option is :: $option"


#when you use if [ "$option" == "y" ] ; it is giving error
# instead of sh script.sh, use bash script.sh, which have more options
# or use = instead of ==, this solves the problem

if [ "$option" = "y" ] ;
then
	echo "INSIDE TRUE"
mysql --local-infile --user=$username --password=$passwd -e "truncate table complaints_db.complaints;
load data local infile 'Consumer_Complaints_v1_cleaned.csv' into table complaints_db.complaints columns terminated by ','  enclosed by '\"' ignore 1 lines ";

else 
		echo "INSIDE false"
	continue;
fi
	



if [ $? -eq 0 ] ;
then
	#Donot give space after =, otherwise gives error
	export message="data loaded successfully"
	print_comments
else
	export message="Failure in data load"
	print_comments
	exit 0
fi
 





export message="Creating usstates table usstates in database"
print_comments

mysql --user=$username --password=$passwd -e "

create table if not exists complaints_db.usstates (State varchar(256),
StandardAbbreviation varchar(256),
PostalCode varchar(10),
CapitalCity varchar(256),
-- created_date datetime DEFAULT CURRENT_TIMESTAMP,
-- modified_date datetime DEFAULT CURRENT_TIMESTAMP,
created_date timestamp DEFAULT CURRENT_TIMESTAMP,
modified_date timestamp DEFAULT CURRENT_TIMESTAMP,
id BIGINT NOT NULL AUTO_INCREMENT,
PRIMARY KEY(id)) ";

if [ $? -eq 0 ] ;
then
	#Donot give space after =, otherwise gives error
	export message="Table usstates created successfully"
	print_comments
else
	export message="Failure in creating table usstates"
	print_comments
	exit 0
fi

export message="loading data into table usstates"
print_comments

mysql --local-infile --user=$username --password=$passwd -e "truncate table complaints_db.usstates;
load data local infile 'USStatesAbbreviations.csv' 
into table complaints_db.usstates 
columns terminated by ','  
enclosed by '\"' ignore 1 lines  ";

if [ $? -eq 0 ] ;
then
	#Donot give space after =, otherwise gives error
	export message="data loaded successfully"
	print_comments
else
	export message="Failure in data load"
	print_comments
	exit 0
fi




export message="Creating Triggers on modified_date to identify incremental data"
print_comments


mysql  --user=$username --password=$passwd -e " use complaints_db ;
delimiter //
drop trigger if exists modifiedDate_Complaint //

create trigger modifiedDate_Complaint before update on complaints_db.complaints
for each row begin
  SET NEW.modified_date=now() ;
end;
//
delimiter ;


delimiter //
drop trigger if exists modifiedDate_usstates //

create trigger modifiedDate_usstates before update on complaints_db.usstates
for each row begin
  SET NEW.modified_date=now() ;
end;
//
delimiter ; " ;

if [ $? -eq 0 ] ;
then
	#Donot give space after =, otherwise gives error
	export message="Triggers created successfully"
	print_comments
else
	export message="Failure in creating Triggers"
	print_comments
	exit 0
fi



